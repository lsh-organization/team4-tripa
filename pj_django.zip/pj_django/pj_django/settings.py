import os
from dotenv import load_dotenv
from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent
#DEPLOY = False
DEPLOY = True #PythonAnywhere에 올릴 때만 True로

# .env 파일 불러오기
load_dotenv(
    BASE_DIR / ".env"
)

# 카카오맵 API Key
KAKAO_MAP_API_KEY = os.getenv(
    "KAKAO_MAP_API_KEY"
)

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/6.1/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-3@^-*@q8(2vf-24@!86r1^4^p!s730av90edxy%25fx)k&khm-'

# SECURITY WARNING: don't run with debug turned on in production!
#DEBUG = True
DEBUG = not DEPLOY
if DEPLOY:
    ALLOWED_HOSTS = ['shlee.pythonanywhere.com']
    CSRF_TRUSTED_ORIGINS = ['https://shlee.pythonanywhere.com']
else:
    #ALLOWED_HOSTS = []
    ALLOWED_HOSTS = ['127.0.0.1', 'localhost', '192.168.1.11']

# 카카오 REST API키
KAKAO_REST_API_KEY = "a42d762a9d581241570816b03ff39930"

# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'sherpaapp.apps.SherpaappConfig',
    
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'pj_django.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'sherpaapp.context_processors.login_member',
                'sherpaapp.context_processors.kakao_api_key',
            ],
        },
    },
]

WSGI_APPLICATION = 'pj_django.wsgi.application'


# Database
# https://docs.djangoproject.com/en/6.1/ref/settings/#databases

# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.mysql',
#         'NAME': 'sherpa_schema',
#         'USER': 'sherpa',
#         'PASSWORD': '1234',
#         'HOST': '127.0.0.1',
#         'PORT': '3306',
#         'OPTIONS': {
#             'charset': 'utf8mb4',
#             'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
#         },
#     }
# }
if DEPLOY:
#if True:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }
else:
    DATABASES = {
                'default': {
                    'ENGINE': 'django.db.backends.mysql',
                    'NAME': 'sherpa_schema',
                    'USER': 'sherpa',
                    'PASSWORD': '1234',
                    'HOST': '127.0.0.1',
                    'PORT': '3306',
                    'OPTIONS': {
                        'charset': 'utf8mb4',
                        'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
                    },
                }
            }


# Password validation
# https://docs.djangoproject.com/en/6.1/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization
# https://docs.djangoproject.com/en/6.1/topics/i18n/

LANGUAGE_CODE = 'en-us'

#TIME_ZONE = 'UTC'
TIME_ZONE = 'Asia/Seoul'


USE_I18N = True

#USE_TZ = True
USE_TZ = False

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/6.1/howto/static-files/

STATIC_URL = 'static/' #
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

if DEPLOY:
    MAX_UPLOAD_MB = 2
else:
    MAX_UPLOAD_MB = 5

SESSION_COOKIE_AGE = 1800
SESSION_SAVE_EVERY_REQUEST = True


# Email
# https://docs.djangoproject.com/en/6.1/topics/email/#topic-email-configuration

MAILERS = {
    'default': {
        'BACKEND': 'django.core.mail.backends.console.EmailBackend',
    },
}
